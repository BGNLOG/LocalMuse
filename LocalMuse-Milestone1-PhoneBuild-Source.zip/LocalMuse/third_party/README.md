# Native dependency bootstrap

`llama.cpp` is intentionally not duplicated into this source bundle. Run:

```bash
./scripts/bootstrap-llama.sh
```

or on Windows PowerShell:

```powershell
./scripts/bootstrap-llama.ps1
```

The script fetches the exact Git commit recorded in `DEVELOPMENT.md`. The Android app never downloads llama.cpp or any inference dependency at runtime.
