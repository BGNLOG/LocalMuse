# JNI looks up callback methods by name. Keep this tiny bridge surface stable when R8 is enabled.
-keep class com.localmuse.inference.nativebridge.NativeLlamaBridge { *; }
-keep class * implements com.localmuse.inference.nativebridge.NativeGenerationCallback { *; }
-keep interface com.localmuse.inference.nativebridge.NativeGenerationCallback { *; }
