package com.localmuse.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.localmuse.chat.ChatScreen
import com.localmuse.chat.ChatViewModel
import com.localmuse.ui.theme.LocalMuseTheme

class MainActivity : ComponentActivity() {
    private val appContainer: AppContainer
        get() = (application as LocalMuseApplication).container

    private val viewModel: ChatViewModel by viewModels {
        ChatViewModel.Factory(
            inference = appContainer.inference,
            modelImporter = appContainer.modelImporter,
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LocalMuseTheme {
                val modelPicker = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.OpenDocument(),
                ) { uri ->
                    if (uri != null) viewModel.importModel(uri)
                }

                ChatScreen(
                    viewModel = viewModel,
                    onSelectModel = {
                        // GGUF providers frequently report application/octet-stream or no useful
                        // MIME type, so extension/header validation happens after SAF selection.
                        modelPicker.launch(arrayOf("*/*"))
                    },
                )
            }
        }
    }
}
