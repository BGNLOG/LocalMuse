package com.localmuse.app

import android.app.Application
import com.localmuse.inference.LlamaCppInferenceEngine
import com.localmuse.models.importer.ModelImporter

class LocalMuseApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

class AppContainer(application: Application) {
    // Application scope is deliberate: Activity recreation must not tear down a 1+ GB model.
    val inference by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { LlamaCppInferenceEngine() }
    val modelImporter by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { ModelImporter(application) }
}
