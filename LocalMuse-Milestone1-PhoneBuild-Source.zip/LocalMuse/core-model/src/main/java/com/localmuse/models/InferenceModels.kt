package com.localmuse.models

import java.util.UUID
import kotlin.math.max
import kotlin.math.min

enum class ChatRole(val wireValue: String) {
    SYSTEM("system"),
    USER("user"),
    ASSISTANT("assistant")
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: ChatRole,
    val content: String,
)

data class ModelConfig(
    val contextSize: Int = 2_048,
    val threadCount: Int = recommendedThreadCount(),
    val batchSize: Int = 256,
) {
    init {
        require(contextSize in 256..131_072) { "Context size is outside the supported safety range." }
        require(threadCount in 1..32) { "Thread count must be between 1 and 32." }
        require(batchSize in 16..2_048) { "Batch size must be between 16 and 2048." }
        require(batchSize <= contextSize) { "Batch size cannot exceed context size." }
    }

    companion object {
        fun recommendedThreadCount(processors: Int = Runtime.getRuntime().availableProcessors()): Int {
            // Galaxy A53 / Exynos 1280 has 8 CPU cores. Four threads is deliberately
            // conservative to reduce thermal throttling and UI starvation.
            return min(4, max(1, processors.coerceAtLeast(1)))
        }
    }
}

data class SamplingConfig(
    val temperature: Float = 0.8f,
    val topK: Int = 40,
    val topP: Float = 0.95f,
    val minP: Float = 0.05f,
    val repetitionPenalty: Float = 1.05f,
    val repetitionWindow: Int = 64,
    val seed: Long = -1L,
    val maxOutputTokens: Int = 512,
    val stopSequences: List<String> = emptyList(),
) {
    init {
        require(temperature in 0f..5f)
        require(topK in 0..10_000)
        require(topP in 0f..1f)
        require(minP in 0f..1f)
        require(repetitionPenalty in 0.1f..4f)
        require(repetitionWindow in 0..32_768)
        require(maxOutputTokens in 1..32_768)
    }
}

data class GenerationRequest(
    val messages: List<ChatMessage>,
    val sampling: SamplingConfig = SamplingConfig(),
) {
    init {
        require(messages.isNotEmpty()) { "At least one message is required." }
    }
}

data class ModelInfo(
    val displayName: String,
    val path: String,
    val description: String,
    val architecture: String,
    val quantization: String,
    val parameterCount: Long,
    val modelSizeBytes: Long,
    val trainedContextSize: Int,
    val activeContextSize: Int,
    val chatTemplate: String?,
    val llamaVersion: String,
)

data class RuntimeStats(
    val promptTokens: Int = 0,
    val tokensGenerated: Int = 0,
    val tokensPerSecond: Double = 0.0,
    val elapsedMillis: Long = 0,
    val contextUsed: Int = 0,
    val contextMaximum: Int = 0,
)

enum class InferenceErrorCode {
    MODEL_NOT_LOADED,
    MODEL_LOAD_FAILED,
    INVALID_MODEL,
    OUT_OF_MEMORY,
    CONTEXT_OVERFLOW,
    TEMPLATE_ERROR,
    NATIVE_ERROR,
    CANCELLED,
}

data class InferenceFailure(
    val code: InferenceErrorCode,
    val userMessage: String,
    val technicalDetail: String? = null,
)

sealed interface GenerationEvent {
    data class Started(val promptTokens: Int, val contextSize: Int) : GenerationEvent
    data class Token(val text: String, val tokenCount: Int) : GenerationEvent
    data class Stats(val stats: RuntimeStats) : GenerationEvent
    data class Completed(val stats: RuntimeStats) : GenerationEvent
    data class Cancelled(val stats: RuntimeStats) : GenerationEvent
    data class Error(val failure: InferenceFailure) : GenerationEvent
}
