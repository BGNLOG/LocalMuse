package com.localmuse.models

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class InferenceModelsTest {
    @Test
    fun galaxyClassDefaultIsConservative() {
        val config = ModelConfig(threadCount = ModelConfig.recommendedThreadCount(8))
        assertEquals(2_048, config.contextSize)
        assertEquals(4, config.threadCount)
        assertEquals(256, config.batchSize)
    }

    @Test
    fun threadRecommendationDoesNotOversubscribeSmallCpu() {
        assertEquals(1, ModelConfig.recommendedThreadCount(1))
        assertEquals(2, ModelConfig.recommendedThreadCount(2))
        assertEquals(4, ModelConfig.recommendedThreadCount(8))
    }

    @Test
    fun rejectsBatchLargerThanContext() {
        assertThrows(IllegalArgumentException::class.java) {
            ModelConfig(contextSize = 256, batchSize = 512)
        }
    }
}
