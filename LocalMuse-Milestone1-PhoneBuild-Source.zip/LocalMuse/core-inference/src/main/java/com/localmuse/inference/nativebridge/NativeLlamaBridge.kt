package com.localmuse.inference.nativebridge

internal interface NativeGenerationCallback {
    fun onStarted(promptTokens: Int, contextSize: Int)
    fun onToken(bytes: ByteArray, tokenCount: Int)
    fun onStats(
        generatedTokens: Int,
        promptTokens: Int,
        elapsedMillis: Long,
        tokensPerSecond: Double,
        contextUsed: Int,
        contextMaximum: Int,
    )
    fun onComplete(generatedTokens: Int, elapsedMillis: Long, stopped: Boolean)
    fun onError(code: String, message: String)
}

internal object NativeLlamaBridge {
    init {
        System.loadLibrary("localmuse_jni")
    }

    external fun nativeCreate(): Long

    /**
     * Result layout:
     * 0 status, 1 detail, 2 description, 3 architecture, 4 quantization,
     * 5 parameter count, 6 model tensor bytes, 7 trained context,
     * 8 active context, 9 embedded chat template, 10 llama.cpp version.
     */
    external fun nativeLoadModel(
        handle: Long,
        modelPath: String,
        contextSize: Int,
        threadCount: Int,
        batchSize: Int,
    ): Array<String>

    external fun nativeGenerate(
        handle: Long,
        roles: Array<String>,
        contents: Array<String>,
        temperature: Float,
        topK: Int,
        topP: Float,
        minP: Float,
        repetitionPenalty: Float,
        repetitionWindow: Int,
        seed: Long,
        maxOutputTokens: Int,
        stopSequences: Array<String>,
        callback: NativeGenerationCallback,
    )

    external fun nativeStop(handle: Long)
    external fun nativeUnload(handle: Long)
    external fun nativeDestroy(handle: Long)
}
