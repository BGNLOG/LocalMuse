package com.localmuse.inference

import com.localmuse.inference.nativebridge.NativeGenerationCallback
import com.localmuse.inference.nativebridge.NativeLlamaBridge
import com.localmuse.models.GenerationEvent
import com.localmuse.models.GenerationRequest
import com.localmuse.models.InferenceErrorCode
import com.localmuse.models.InferenceFailure
import com.localmuse.models.ModelConfig
import com.localmuse.models.ModelInfo
import com.localmuse.models.RuntimeStats
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LlamaCppInferenceEngine : LocalInferenceEngine, AutoCloseable {
    private val executor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "LocalMuse-llama.cpp").apply {
            priority = Thread.NORM_PRIORITY
        }
    }
    private val dispatcher: CoroutineDispatcher = executor.asCoroutineDispatcher()
    private val handle: Long = NativeLlamaBridge.nativeCreate().also {
        check(it != 0L) { "Could not create native llama.cpp engine." }
    }

    @Volatile
    private var modelInfo: ModelInfo? = null

    private val stats = AtomicReference(RuntimeStats())

    override suspend fun loadModel(modelPath: String, config: ModelConfig): Result<ModelInfo> =
        withContext(dispatcher) {
            runCatching {
                // Loading a second model first releases the previous model/context.
                NativeLlamaBridge.nativeUnload(handle)
                modelInfo = null
                stats.set(RuntimeStats())

                val result = NativeLlamaBridge.nativeLoadModel(
                    handle = handle,
                    modelPath = modelPath,
                    contextSize = config.contextSize,
                    threadCount = config.threadCount,
                    batchSize = config.batchSize,
                )

                val status = result.getOrNull(0).orEmpty()
                if (status != "OK") {
                    throw LocalInferenceException(
                        code = status.toErrorCode(),
                        userMessage = result.getOrNull(1).orEmpty().ifBlank {
                            "The model could not be loaded on this device."
                        },
                    )
                }

                val info = ModelInfo(
                    displayName = File(modelPath).name,
                    path = modelPath,
                    description = result.getOrNull(2).orEmpty(),
                    architecture = result.getOrNull(3).orEmpty(),
                    quantization = result.getOrNull(4).orEmpty(),
                    parameterCount = result.getOrNull(5)?.toLongOrNull() ?: 0L,
                    modelSizeBytes = result.getOrNull(6)?.toLongOrNull() ?: File(modelPath).length(),
                    trainedContextSize = result.getOrNull(7)?.toIntOrNull() ?: 0,
                    activeContextSize = result.getOrNull(8)?.toIntOrNull() ?: config.contextSize,
                    chatTemplate = result.getOrNull(9)?.takeIf(String::isNotBlank),
                    llamaVersion = result.getOrNull(10).orEmpty(),
                )
                modelInfo = info
                info
            }
        }

    override fun generate(request: GenerationRequest): Flow<GenerationEvent> = callbackFlow {
        val loaded = modelInfo
        if (loaded == null) {
            trySend(
                GenerationEvent.Error(
                    InferenceFailure(
                        InferenceErrorCode.MODEL_NOT_LOADED,
                        "Import and load a GGUF model before sending a message.",
                    ),
                ),
            )
            close()
            return@callbackFlow
        }

        val generation = launch(dispatcher) {
            val callback = object : NativeGenerationCallback {
                private var promptTokens = 0
                private var contextMaximum = loaded.activeContextSize

                override fun onStarted(promptTokens: Int, contextSize: Int) {
                    this.promptTokens = promptTokens
                    contextMaximum = contextSize
                    trySend(GenerationEvent.Started(promptTokens, contextSize))
                }

                override fun onToken(bytes: ByteArray, tokenCount: Int) {
                    if (bytes.isEmpty()) return
                    val text = bytes.toString(Charsets.UTF_8)
                    if (text.isNotEmpty()) {
                        trySend(GenerationEvent.Token(text, tokenCount))
                    }
                }

                override fun onStats(
                    generatedTokens: Int,
                    promptTokens: Int,
                    elapsedMillis: Long,
                    tokensPerSecond: Double,
                    contextUsed: Int,
                    contextMaximum: Int,
                ) {
                    val current = RuntimeStats(
                        promptTokens = promptTokens,
                        tokensGenerated = generatedTokens,
                        tokensPerSecond = tokensPerSecond,
                        elapsedMillis = elapsedMillis,
                        contextUsed = contextUsed,
                        contextMaximum = contextMaximum,
                    )
                    stats.set(current)
                    trySend(GenerationEvent.Stats(current))
                }

                override fun onComplete(generatedTokens: Int, elapsedMillis: Long, stopped: Boolean) {
                    val previous = stats.get()
                    val current = previous.copy(
                        promptTokens = promptTokens,
                        tokensGenerated = generatedTokens,
                        elapsedMillis = elapsedMillis,
                        contextMaximum = contextMaximum,
                    )
                    stats.set(current)
                    if (stopped) {
                        trySend(GenerationEvent.Cancelled(current))
                    } else {
                        trySend(GenerationEvent.Completed(current))
                    }
                }

                override fun onError(code: String, message: String) {
                    trySend(
                        GenerationEvent.Error(
                            InferenceFailure(
                                code = code.toErrorCode(),
                                userMessage = message.ifBlank { "Local generation failed." },
                            ),
                        ),
                    )
                }
            }

            try {
                NativeLlamaBridge.nativeGenerate(
                    handle = handle,
                    roles = request.messages.map { it.role.wireValue }.toTypedArray(),
                    contents = request.messages.map { it.content }.toTypedArray(),
                    temperature = request.sampling.temperature,
                    topK = request.sampling.topK,
                    topP = request.sampling.topP,
                    minP = request.sampling.minP,
                    repetitionPenalty = request.sampling.repetitionPenalty,
                    repetitionWindow = request.sampling.repetitionWindow,
                    seed = request.sampling.seed,
                    maxOutputTokens = request.sampling.maxOutputTokens,
                    stopSequences = request.sampling.stopSequences.toTypedArray(),
                    callback = callback,
                )
            } catch (oom: OutOfMemoryError) {
                trySend(
                    GenerationEvent.Error(
                        InferenceFailure(
                            InferenceErrorCode.OUT_OF_MEMORY,
                            "Android ran out of memory during generation. Try a smaller model or context size.",
                            oom.message,
                        ),
                    ),
                )
            } catch (t: Throwable) {
                trySend(
                    GenerationEvent.Error(
                        InferenceFailure(
                            InferenceErrorCode.NATIVE_ERROR,
                            "The local inference engine stopped unexpectedly.",
                            t.message,
                        ),
                    ),
                )
            } finally {
                close()
            }
        }

        awaitClose {
            // This is intentionally direct instead of queued on dispatcher: the native
            // generation call occupies that worker. nativeStop only flips an atomic flag.
            NativeLlamaBridge.nativeStop(handle)
            generation.cancel()
        }
    }

    override suspend fun stopGeneration() {
        NativeLlamaBridge.nativeStop(handle)
    }

    override suspend fun unloadModel() = withContext(dispatcher) {
        NativeLlamaBridge.nativeUnload(handle)
        modelInfo = null
        stats.set(RuntimeStats())
    }

    override fun getModelInfo(): ModelInfo? = modelInfo

    override fun getRuntimeStats(): RuntimeStats = stats.get()

    override fun close() {
        NativeLlamaBridge.nativeStop(handle)
        // Native unload/destroy cannot race with generation because normal app lifecycle
        // keeps this application-scoped engine alive. close() is reserved for process/test teardown.
        NativeLlamaBridge.nativeDestroy(handle)
        executor.shutdown()
    }
}

class LocalInferenceException(
    val code: InferenceErrorCode,
    val userMessage: String,
) : IllegalStateException(userMessage)

private fun String.toErrorCode(): InferenceErrorCode = when (this) {
    "MODEL_NOT_LOADED" -> InferenceErrorCode.MODEL_NOT_LOADED
    "MODEL_LOAD_FAILED" -> InferenceErrorCode.MODEL_LOAD_FAILED
    "INVALID_MODEL" -> InferenceErrorCode.INVALID_MODEL
    "OUT_OF_MEMORY" -> InferenceErrorCode.OUT_OF_MEMORY
    "CONTEXT_OVERFLOW" -> InferenceErrorCode.CONTEXT_OVERFLOW
    "TEMPLATE_ERROR" -> InferenceErrorCode.TEMPLATE_ERROR
    "CANCELLED" -> InferenceErrorCode.CANCELLED
    else -> InferenceErrorCode.NATIVE_ERROR
}
