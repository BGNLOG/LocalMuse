package com.localmuse.inference

import com.localmuse.models.GenerationEvent
import com.localmuse.models.GenerationRequest
import com.localmuse.models.ModelConfig
import com.localmuse.models.ModelInfo
import com.localmuse.models.RuntimeStats
import kotlinx.coroutines.flow.Flow

interface LocalInferenceEngine {
    suspend fun loadModel(modelPath: String, config: ModelConfig): Result<ModelInfo>
    fun generate(request: GenerationRequest): Flow<GenerationEvent>
    suspend fun stopGeneration()
    suspend fun unloadModel()
    fun getModelInfo(): ModelInfo?
    fun getRuntimeStats(): RuntimeStats
}
