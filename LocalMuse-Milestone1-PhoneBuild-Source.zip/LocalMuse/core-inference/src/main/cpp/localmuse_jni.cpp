#include <jni.h>
#include <android/log.h>

#include "llama.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <exception>
#include <limits>
#include <mutex>
#include <new>
#include <string>
#include <utility>
#include <vector>

namespace {

constexpr const char * kLogTag = "LocalMuseNative";

#define LM_LOGE(...) __android_log_print(ANDROID_LOG_ERROR, kLogTag, __VA_ARGS__)
#define LM_LOGW(...) __android_log_print(ANDROID_LOG_WARN,  kLogTag, __VA_ARGS__)
#define LM_LOGI(...) __android_log_print(ANDROID_LOG_INFO,  kLogTag, __VA_ARGS__)

std::once_flag g_backend_once;

void ensure_backend_initialized() {
    std::call_once(g_backend_once, [] {
        llama_backend_init();
        LM_LOGI("llama.cpp backend initialized: %s", llama_version());
    });
}

std::string utf16_to_utf8(JNIEnv * env, jstring value) {
    if (value == nullptr) return {};
    const jsize length = env->GetStringLength(value);
    const jchar * chars = env->GetStringChars(value, nullptr);
    if (chars == nullptr) return {};

    std::string out;
    out.reserve(static_cast<size_t>(length) * 2);

    for (jsize i = 0; i < length; ++i) {
        uint32_t cp = chars[i];
        if (cp >= 0xD800 && cp <= 0xDBFF && i + 1 < length) {
            const uint32_t low = chars[i + 1];
            if (low >= 0xDC00 && low <= 0xDFFF) {
                cp = 0x10000 + ((cp - 0xD800) << 10) + (low - 0xDC00);
                ++i;
            } else {
                cp = 0xFFFD;
            }
        } else if (cp >= 0xDC00 && cp <= 0xDFFF) {
            cp = 0xFFFD;
        }

        if (cp <= 0x7F) {
            out.push_back(static_cast<char>(cp));
        } else if (cp <= 0x7FF) {
            out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else if (cp <= 0xFFFF) {
            out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else {
            out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        }
    }

    env->ReleaseStringChars(value, chars);
    return out;
}

jstring utf8_to_jstring(JNIEnv * env, const std::string & input) {
    std::vector<jchar> utf16;
    utf16.reserve(input.size());

    const auto * bytes = reinterpret_cast<const unsigned char *>(input.data());
    size_t i = 0;
    while (i < input.size()) {
        uint32_t cp = 0xFFFD;
        size_t width = 1;
        const unsigned char c = bytes[i];

        if (c <= 0x7F) {
            cp = c;
            width = 1;
        } else if ((c & 0xE0) == 0xC0 && i + 1 < input.size() && (bytes[i + 1] & 0xC0) == 0x80) {
            cp = ((c & 0x1F) << 6) | (bytes[i + 1] & 0x3F);
            width = cp >= 0x80 ? 2 : 1;
            if (width == 1) cp = 0xFFFD;
        } else if ((c & 0xF0) == 0xE0 && i + 2 < input.size() &&
                   (bytes[i + 1] & 0xC0) == 0x80 && (bytes[i + 2] & 0xC0) == 0x80) {
            cp = ((c & 0x0F) << 12) | ((bytes[i + 1] & 0x3F) << 6) | (bytes[i + 2] & 0x3F);
            width = (cp >= 0x800 && !(cp >= 0xD800 && cp <= 0xDFFF)) ? 3 : 1;
            if (width == 1) cp = 0xFFFD;
        } else if ((c & 0xF8) == 0xF0 && i + 3 < input.size() &&
                   (bytes[i + 1] & 0xC0) == 0x80 && (bytes[i + 2] & 0xC0) == 0x80 &&
                   (bytes[i + 3] & 0xC0) == 0x80) {
            cp = ((c & 0x07) << 18) | ((bytes[i + 1] & 0x3F) << 12) |
                 ((bytes[i + 2] & 0x3F) << 6) | (bytes[i + 3] & 0x3F);
            width = (cp >= 0x10000 && cp <= 0x10FFFF) ? 4 : 1;
            if (width == 1) cp = 0xFFFD;
        }

        i += width;
        if (cp <= 0xFFFF) {
            utf16.push_back(static_cast<jchar>(cp));
        } else {
            cp -= 0x10000;
            utf16.push_back(static_cast<jchar>(0xD800 + (cp >> 10)));
            utf16.push_back(static_cast<jchar>(0xDC00 + (cp & 0x3FF)));
        }
    }

    return env->NewString(utf16.data(), static_cast<jsize>(utf16.size()));
}

std::vector<std::string> read_string_array(JNIEnv * env, jobjectArray array) {
    std::vector<std::string> result;
    if (array == nullptr) return result;
    const jsize count = env->GetArrayLength(array);
    result.reserve(static_cast<size_t>(count));
    for (jsize i = 0; i < count; ++i) {
        auto value = static_cast<jstring>(env->GetObjectArrayElement(array, i));
        result.emplace_back(utf16_to_utf8(env, value));
        if (value != nullptr) env->DeleteLocalRef(value);
    }
    return result;
}

jobjectArray make_string_array(JNIEnv * env, const std::vector<std::string> & values) {
    jclass string_class = env->FindClass("java/lang/String");
    if (string_class == nullptr) return nullptr;
    jobjectArray output = env->NewObjectArray(static_cast<jsize>(values.size()), string_class, nullptr);
    for (size_t i = 0; i < values.size(); ++i) {
        jstring value = utf8_to_jstring(env, values[i]);
        env->SetObjectArrayElement(output, static_cast<jsize>(i), value);
        env->DeleteLocalRef(value);
    }
    env->DeleteLocalRef(string_class);
    return output;
}

struct EngineState {
    std::mutex mutex;
    std::atomic<bool> stop_requested{false};
    llama_model * model = nullptr;
    llama_context * context = nullptr;

    void unload_locked() {
        if (context != nullptr) {
            llama_free(context);
            context = nullptr;
        }
        if (model != nullptr) {
            llama_model_free(model);
            model = nullptr;
        }
    }

    ~EngineState() {
        unload_locked();
    }
};

EngineState * from_handle(jlong handle) {
    return reinterpret_cast<EngineState *>(static_cast<intptr_t>(handle));
}

std::string model_meta_string(const llama_model * model, const char * key) {
    std::vector<char> buffer(512, '\0');
    int32_t result = llama_model_meta_val_str(model, key, buffer.data(), buffer.size());
    if (result < 0) return {};
    if (static_cast<size_t>(result) >= buffer.size()) {
        buffer.assign(static_cast<size_t>(result) + 1, '\0');
        result = llama_model_meta_val_str(model, key, buffer.data(), buffer.size());
        if (result < 0) return {};
    }
    return std::string(buffer.data(), static_cast<size_t>(result));
}

std::string model_description(const llama_model * model) {
    std::vector<char> buffer(1024, '\0');
    int32_t result = llama_model_desc(model, buffer.data(), buffer.size());
    if (result < 0) return {};
    if (static_cast<size_t>(result) >= buffer.size()) {
        buffer.assign(static_cast<size_t>(result) + 1, '\0');
        result = llama_model_desc(model, buffer.data(), buffer.size());
        if (result < 0) return {};
    }
    return std::string(buffer.data());
}

struct Callback {
    JNIEnv * env;
    jobject target;
    jmethodID started;
    jmethodID token;
    jmethodID stats;
    jmethodID complete;
    jmethodID error;

    explicit Callback(JNIEnv * e, jobject callback) : env(e), target(callback) {
        jclass cls = env->GetObjectClass(callback);
        started = env->GetMethodID(cls, "onStarted", "(II)V");
        token = env->GetMethodID(cls, "onToken", "([BI)V");
        stats = env->GetMethodID(cls, "onStats", "(IIJDII)V");
        complete = env->GetMethodID(cls, "onComplete", "(IJZ)V");
        error = env->GetMethodID(cls, "onError", "(Ljava/lang/String;Ljava/lang/String;)V");
        env->DeleteLocalRef(cls);
    }

    void on_started(int prompt_tokens, int context_size) const {
        env->CallVoidMethod(target, started, static_cast<jint>(prompt_tokens), static_cast<jint>(context_size));
    }

    void on_token(const char * data, size_t size, int token_count) const {
        if (size == 0) return;
        jbyteArray bytes = env->NewByteArray(static_cast<jsize>(size));
        if (bytes == nullptr) return;
        env->SetByteArrayRegion(bytes, 0, static_cast<jsize>(size), reinterpret_cast<const jbyte *>(data));
        env->CallVoidMethod(target, token, bytes, static_cast<jint>(token_count));
        env->DeleteLocalRef(bytes);
    }

    void on_stats(
        int generated,
        int prompt_tokens,
        int64_t elapsed_ms,
        double tokens_per_second,
        int context_used,
        int context_max) const {
        env->CallVoidMethod(
            target,
            stats,
            static_cast<jint>(generated),
            static_cast<jint>(prompt_tokens),
            static_cast<jlong>(elapsed_ms),
            static_cast<jdouble>(tokens_per_second),
            static_cast<jint>(context_used),
            static_cast<jint>(context_max));
    }

    void on_complete(int generated, int64_t elapsed_ms, bool stopped) const {
        env->CallVoidMethod(
            target,
            complete,
            static_cast<jint>(generated),
            static_cast<jlong>(elapsed_ms),
            static_cast<jboolean>(stopped));
    }

    void on_error(const std::string & code, const std::string & message) const {
        jstring j_code = utf8_to_jstring(env, code);
        jstring j_message = utf8_to_jstring(env, message);
        env->CallVoidMethod(target, error, j_code, j_message);
        env->DeleteLocalRef(j_code);
        env->DeleteLocalRef(j_message);
    }
};

std::string build_prompt(
    const llama_model * model,
    const std::vector<std::string> & roles,
    const std::vector<std::string> & contents,
    std::string & error) {

    const size_t count = std::min(roles.size(), contents.size());
    if (count == 0) {
        error = "The conversation is empty.";
        return {};
    }

    std::vector<llama_chat_message> messages;
    messages.reserve(count);
    for (size_t i = 0; i < count; ++i) {
        messages.push_back({roles[i].c_str(), contents[i].c_str()});
    }

    const char * tmpl = llama_model_chat_template(model, nullptr);
    if (tmpl != nullptr && tmpl[0] != '\0') {
        int32_t required = llama_chat_apply_template(
            tmpl, messages.data(), messages.size(), true, nullptr, 0);
        if (required < 0) {
            error = "The GGUF contains a chat template that this llama.cpp build cannot apply.";
            return {};
        }

        std::vector<char> buffer(static_cast<size_t>(required) + 1, '\0');
        int32_t written = llama_chat_apply_template(
            tmpl,
            messages.data(),
            messages.size(),
            true,
            buffer.data(),
            static_cast<int32_t>(buffer.size()));
        if (written < 0 || written > static_cast<int32_t>(buffer.size())) {
            error = "The embedded GGUF chat template could not be rendered safely.";
            return {};
        }
        return std::string(buffer.data(), static_cast<size_t>(written));
    }

    // Generic fallback only for GGUFs that provide no template at all. This is deliberately
    // not a model-specific Qwen/ChatML template. Base models can therefore still be prompted.
    std::string prompt;
    for (size_t i = 0; i < count; ++i) {
        if (roles[i] == "system") {
            prompt += contents[i];
            prompt += "\n\n";
        } else if (roles[i] == "assistant") {
            prompt += "Assistant:\n";
            prompt += contents[i];
            prompt += "\n\n";
        } else {
            prompt += "User:\n";
            prompt += contents[i];
            prompt += "\n\n";
        }
    }
    prompt += "Assistant:\n";
    return prompt;
}

bool tokenize_prompt(
    const llama_vocab * vocab,
    const std::string & prompt,
    std::vector<llama_token> & tokens,
    std::string & error) {

    const int32_t count = llama_tokenize(
        vocab,
        prompt.data(),
        static_cast<int32_t>(prompt.size()),
        nullptr,
        0,
        true,
        true);

    if (count == 0) {
        error = "The rendered prompt produced no tokens.";
        return false;
    }

    const int32_t required = count < 0 ? -count : count;
    tokens.resize(static_cast<size_t>(required));
    const int32_t actual = llama_tokenize(
        vocab,
        prompt.data(),
        static_cast<int32_t>(prompt.size()),
        tokens.data(),
        static_cast<int32_t>(tokens.size()),
        true,
        true);

    if (actual < 0) {
        error = "The tokenizer could not fit the rendered prompt.";
        return false;
    }
    tokens.resize(static_cast<size_t>(actual));
    return true;
}

std::string token_piece(const llama_vocab * vocab, llama_token token) {
    std::vector<char> buffer(128);
    int32_t count = llama_token_to_piece(
        vocab, token, buffer.data(), static_cast<int32_t>(buffer.size()), 0, true);
    if (count < 0) {
        buffer.resize(static_cast<size_t>(-count));
        count = llama_token_to_piece(
            vocab, token, buffer.data(), static_cast<int32_t>(buffer.size()), 0, true);
    }
    if (count <= 0) return {};
    return std::string(buffer.data(), static_cast<size_t>(count));
}

size_t complete_utf8_prefix(const std::string & value, size_t limit) {
    limit = std::min(limit, value.size());
    size_t i = 0;
    while (i < limit) {
        const auto c = static_cast<unsigned char>(value[i]);
        size_t width = 1;
        if (c <= 0x7F) {
            width = 1;
        } else if ((c & 0xE0) == 0xC0) {
            width = 2;
        } else if ((c & 0xF0) == 0xE0) {
            width = 3;
        } else if ((c & 0xF8) == 0xF0) {
            width = 4;
        } else {
            // Unexpected invalid byte. Keep it buffered until the final flush rather than
            // handing Kotlin half of a UTF-8 sequence.
            break;
        }
        if (i + width > limit) break;
        bool valid = true;
        for (size_t j = 1; j < width; ++j) {
            if ((static_cast<unsigned char>(value[i + j]) & 0xC0) != 0x80) {
                valid = false;
                break;
            }
        }
        if (!valid) break;
        i += width;
    }
    return i;
}

class StopStreamer {
public:
    StopStreamer(std::vector<std::string> stops, Callback & callback)
        : stops_(std::move(stops)), callback_(callback) {
        stops_.erase(
            std::remove_if(stops_.begin(), stops_.end(), [](const std::string & s) { return s.empty(); }),
            stops_.end());
    }

    // Returns true when a configured stop sequence was reached.
    bool push(const std::string & bytes, int token_count) {
        pending_ += bytes;

        size_t earliest_stop = std::string::npos;
        for (const auto & stop : stops_) {
            const size_t pos = pending_.find(stop);
            if (pos != std::string::npos) earliest_stop = std::min(earliest_stop, pos);
        }
        if (earliest_stop != std::string::npos) {
            emit_prefix(complete_utf8_prefix(pending_, earliest_stop), token_count);
            pending_.clear();
            return true;
        }

        size_t keep = 0;
        for (const auto & stop : stops_) {
            const size_t max_prefix = std::min(stop.size() - 1, pending_.size());
            for (size_t length = max_prefix; length > keep; --length) {
                if (pending_.compare(pending_.size() - length, length, stop, 0, length) == 0) {
                    keep = length;
                    break;
                }
            }
        }

        const size_t candidate = pending_.size() - keep;
        emit_prefix(complete_utf8_prefix(pending_, candidate), token_count);
        return false;
    }

    void flush(int token_count) {
        if (pending_.empty()) return;
        // llama.cpp token pieces should form valid UTF-8 by the end of generation. If an
        // unusual model leaves invalid bytes, send them as-is and let Kotlin replacement
        // semantics make the corruption visible rather than silently losing content.
        callback_.on_token(pending_.data(), pending_.size(), token_count);
        pending_.clear();
    }

private:
    void emit_prefix(size_t bytes, int token_count) {
        if (bytes == 0) return;
        callback_.on_token(pending_.data(), bytes, token_count);
        pending_.erase(0, bytes);
    }

    std::vector<std::string> stops_;
    Callback & callback_;
    std::string pending_;
};

int64_t millis_since(const std::chrono::steady_clock::time_point & start) {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now() - start).count();
}

struct SamplerGuard {
    llama_sampler * value = nullptr;
    ~SamplerGuard() {
        if (value != nullptr) llama_sampler_free(value);
    }
};

llama_sampler * create_sampler(
    const llama_vocab * vocab,
    float temperature,
    int top_k,
    float top_p,
    float min_p,
    float repetition_penalty,
    int repetition_window,
    int64_t seed) {

    llama_sampler * chain = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (chain == nullptr) return nullptr;

    if (repetition_window > 0 && repetition_penalty > 0.0f && repetition_penalty != 1.0f) {
        llama_sampler_chain_add(
            chain,
            llama_sampler_init_penalties(
                llama_vocab_n_tokens(vocab),
                repetition_window,
                repetition_penalty,
                0.0f,
                0.0f));
    }

    if (top_k > 0) llama_sampler_chain_add(chain, llama_sampler_init_top_k(top_k));
    if (top_p > 0.0f && top_p < 1.0f) llama_sampler_chain_add(chain, llama_sampler_init_top_p(top_p, 1));
    if (min_p > 0.0f) llama_sampler_chain_add(chain, llama_sampler_init_min_p(min_p, 1));

    if (temperature <= 0.0f) {
        llama_sampler_chain_add(chain, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(chain, llama_sampler_init_temp(temperature));
        const uint32_t actual_seed = seed < 0
            ? LLAMA_DEFAULT_SEED
            : static_cast<uint32_t>(static_cast<uint64_t>(seed) & 0xFFFFFFFFu);
        llama_sampler_chain_add(chain, llama_sampler_init_dist(actual_seed));
    }
    return chain;
}

} // namespace

extern "C" JNIEXPORT jlong JNICALL
Java_com_localmuse_inference_nativebridge_NativeLlamaBridge_nativeCreate(
    JNIEnv *, jobject) {
    try {
        ensure_backend_initialized();
        return static_cast<jlong>(reinterpret_cast<intptr_t>(new EngineState()));
    } catch (const std::exception & e) {
        LM_LOGE("nativeCreate failed: %s", e.what());
        return 0;
    } catch (...) {
        LM_LOGE("nativeCreate failed with unknown exception");
        return 0;
    }
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_com_localmuse_inference_nativebridge_NativeLlamaBridge_nativeLoadModel(
    JNIEnv * env,
    jobject,
    jlong handle,
    jstring model_path,
    jint context_size,
    jint thread_count,
    jint batch_size) {

    EngineState * state = from_handle(handle);
    if (state == nullptr) {
        return make_string_array(env, {"NATIVE_ERROR", "Native engine is unavailable.", "", "", "", "0", "0", "0", "0", "", ""});
    }

    const std::string path = utf16_to_utf8(env, model_path);
    std::lock_guard<std::mutex> lock(state->mutex);
    state->stop_requested.store(false, std::memory_order_relaxed);
    state->unload_locked();

    try {
        llama_model_params model_params = llama_model_default_params();
        model_params.n_gpu_layers = 0;
        model_params.load_mode = llama_supports_mmap() ? LLAMA_LOAD_MODE_MMAP : LLAMA_LOAD_MODE_NONE;

        LM_LOGI("Loading model with mmap=%d path=%s", model_params.load_mode == LLAMA_LOAD_MODE_MMAP, path.c_str());
        state->model = llama_model_load_from_file(path.c_str(), model_params);
        if (state->model == nullptr) {
            return make_string_array(env, {"MODEL_LOAD_FAILED", "llama.cpp could not load this GGUF model.", "", "", "", "0", "0", "0", "0", "", llama_version()});
        }

        if (!llama_model_has_decoder(state->model)) {
            state->unload_locked();
            return make_string_array(env, {"MODEL_LOAD_FAILED", "This Milestone 1 build requires a text-generating decoder model.", "", "", "", "0", "0", "0", "0", "", llama_version()});
        }

        llama_context_params context_params = llama_context_default_params();
        context_params.n_ctx = static_cast<uint32_t>(std::max(256, static_cast<int>(context_size)));
        context_params.n_batch = static_cast<uint32_t>(std::max(16, std::min(static_cast<int>(batch_size), static_cast<int>(context_params.n_ctx))));
        context_params.n_ubatch = context_params.n_batch;
        context_params.n_seq_max = 1;
        context_params.n_threads = std::max(1, static_cast<int>(thread_count));
        context_params.n_threads_batch = context_params.n_threads;
        context_params.offload_kqv = false;
        context_params.op_offload = false;
        context_params.abort_callback = [](void * data) -> bool {
            auto * engine = static_cast<EngineState *>(data);
            return engine != nullptr && engine->stop_requested.load(std::memory_order_relaxed);
        };
        context_params.abort_callback_data = state;

        state->context = llama_init_from_model(state->model, context_params);
        if (state->context == nullptr) {
            state->unload_locked();
            return make_string_array(env, {"OUT_OF_MEMORY", "The model opened, but Android could not allocate its runtime context. Try a smaller context or model.", "", "", "", "0", "0", "0", "0", "", llama_version()});
        }

        const std::string description = model_description(state->model);
        const std::string architecture = model_meta_string(state->model, "general.architecture");
        const char * quantization = llama_ftype_name(llama_model_ftype(state->model));
        const char * chat_template = llama_model_chat_template(state->model, nullptr);

        return make_string_array(env, {
            "OK",
            "",
            description,
            architecture,
            quantization == nullptr ? "" : quantization,
            std::to_string(llama_model_n_params(state->model)),
            std::to_string(llama_model_size(state->model)),
            std::to_string(llama_model_n_ctx_train(state->model)),
            std::to_string(llama_n_ctx(state->context)),
            chat_template == nullptr ? "" : chat_template,
            llama_version(),
        });
    } catch (const std::bad_alloc & e) {
        LM_LOGE("Out of memory loading model: %s", e.what());
        state->unload_locked();
        return make_string_array(env, {"OUT_OF_MEMORY", "Not enough memory is available to load this model.", "", "", "", "0", "0", "0", "0", "", llama_version()});
    } catch (const std::exception & e) {
        LM_LOGE("Model load exception: %s", e.what());
        state->unload_locked();
        return make_string_array(env, {"MODEL_LOAD_FAILED", "The GGUF model could not be loaded.", "", "", "", "0", "0", "0", "0", "", llama_version()});
    } catch (...) {
        LM_LOGE("Unknown model load exception");
        state->unload_locked();
        return make_string_array(env, {"MODEL_LOAD_FAILED", "The GGUF model could not be loaded.", "", "", "", "0", "0", "0", "0", "", llama_version()});
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_localmuse_inference_nativebridge_NativeLlamaBridge_nativeGenerate(
    JNIEnv * env,
    jobject,
    jlong handle,
    jobjectArray roles_array,
    jobjectArray contents_array,
    jfloat temperature,
    jint top_k,
    jfloat top_p,
    jfloat min_p,
    jfloat repetition_penalty,
    jint repetition_window,
    jlong seed,
    jint max_output_tokens,
    jobjectArray stop_sequences_array,
    jobject callback_object) {

    EngineState * state = from_handle(handle);
    Callback callback(env, callback_object);
    if (state == nullptr) {
        callback.on_error("NATIVE_ERROR", "Native engine is unavailable.");
        return;
    }

    std::unique_lock<std::mutex> lock(state->mutex);
    if (state->model == nullptr || state->context == nullptr) {
        callback.on_error("MODEL_NOT_LOADED", "Import and load a GGUF model before generating.");
        return;
    }

    state->stop_requested.store(false, std::memory_order_relaxed);
    const auto overall_start = std::chrono::steady_clock::now();

    try {
        const std::vector<std::string> roles = read_string_array(env, roles_array);
        const std::vector<std::string> contents = read_string_array(env, contents_array);
        std::vector<std::string> stop_sequences = read_string_array(env, stop_sequences_array);

        std::string prompt_error;
        const std::string prompt = build_prompt(state->model, roles, contents, prompt_error);
        if (!prompt_error.empty()) {
            callback.on_error("TEMPLATE_ERROR", prompt_error);
            return;
        }

        const llama_vocab * vocab = llama_model_get_vocab(state->model);
        if (vocab == nullptr) {
            callback.on_error("INVALID_MODEL", "The model has no usable tokenizer vocabulary.");
            return;
        }

        std::vector<llama_token> prompt_tokens;
        std::string tokenization_error;
        if (!tokenize_prompt(vocab, prompt, prompt_tokens, tokenization_error)) {
            callback.on_error("INVALID_MODEL", tokenization_error);
            return;
        }

        const int context_max = static_cast<int>(llama_n_ctx(state->context));
        const int prompt_count = static_cast<int>(prompt_tokens.size());
        callback.on_started(prompt_count, context_max);

        if (prompt_count >= context_max) {
            callback.on_error(
                "CONTEXT_OVERFLOW",
                "The prompt is larger than the active context. Start a shorter chat or load the model with a larger context.");
            return;
        }

        llama_memory_clear(llama_get_memory(state->context), true);

        const int batch_max = std::max(1, static_cast<int>(llama_n_batch(state->context)));
        for (int offset = 0; offset < prompt_count; offset += batch_max) {
            if (state->stop_requested.load(std::memory_order_relaxed)) {
                callback.on_complete(0, millis_since(overall_start), true);
                return;
            }
            const int count = std::min(batch_max, prompt_count - offset);
            llama_batch batch = llama_batch_get_one(prompt_tokens.data() + offset, count);
            const int decode_result = llama_decode(state->context, batch);
            if (decode_result == 2 || state->stop_requested.load(std::memory_order_relaxed)) {
                callback.on_complete(0, millis_since(overall_start), true);
                return;
            }
            if (decode_result != 0) {
                LM_LOGE("Prompt decode failed with code %d", decode_result);
                callback.on_error(
                    decode_result == 1 ? "CONTEXT_OVERFLOW" : "NATIVE_ERROR",
                    decode_result == 1
                        ? "The model could not reserve enough context memory for this prompt."
                        : "llama.cpp could not evaluate the prompt.");
                return;
            }
        }

        llama_sampler * sampler = create_sampler(
            vocab,
            temperature,
            top_k,
            top_p,
            min_p,
            repetition_penalty,
            repetition_window,
            seed);
        if (sampler == nullptr) {
            callback.on_error("OUT_OF_MEMORY", "Could not allocate the token sampler.");
            return;
        }
        SamplerGuard sampler_guard{sampler};

        // Seed stateful samplers (most importantly repetition penalties) with the
        // already-evaluated prompt so their configured history window reflects the
        // actual conversation instead of only tokens generated in this call.
        for (const llama_token token : prompt_tokens) {
            llama_sampler_accept(sampler, token);
        }

        StopStreamer streamer(std::move(stop_sequences), callback);
        const auto generation_start = std::chrono::steady_clock::now();
        auto last_stats = generation_start;
        int generated = 0;
        int decoded_generated = 0;
        bool matched_stop_sequence = false;
        bool cancelled = false;
        bool generation_error = false;

        const int token_limit = std::max(1, static_cast<int>(max_output_tokens));
        for (int step = 0; step < token_limit; ++step) {
            if (state->stop_requested.load(std::memory_order_relaxed)) {
                cancelled = true;
                break;
            }

            const llama_token next = llama_sampler_sample(sampler, state->context, -1);
            if (state->stop_requested.load(std::memory_order_relaxed)) {
                cancelled = true;
                break;
            }
            if (llama_vocab_is_eog(vocab, next)) {
                break;
            }

            ++generated;
            const std::string piece = token_piece(vocab, next);
            if (!piece.empty() && streamer.push(piece, generated)) {
                matched_stop_sequence = true;
                break;
            }

            const auto now = std::chrono::steady_clock::now();
            const auto generation_ms = std::max<int64_t>(1, std::chrono::duration_cast<std::chrono::milliseconds>(now - generation_start).count());
            if (generated % 4 == 0 || std::chrono::duration_cast<std::chrono::milliseconds>(now - last_stats).count() >= 250) {
                callback.on_stats(
                    generated,
                    prompt_count,
                    millis_since(overall_start),
                    static_cast<double>(generated) * 1000.0 / static_cast<double>(generation_ms),
                    prompt_count + decoded_generated,
                    context_max);
                last_stats = now;
            }

            if (step + 1 >= token_limit) {
                break;
            }

            const int context_used = prompt_count + decoded_generated;
            if (context_used + 1 >= context_max) {
                streamer.flush(generated);
                callback.on_error(
                    "CONTEXT_OVERFLOW",
                    "The active context is full. Reduce chat history, response length, or increase context size if memory allows.");
                generation_error = true;
                break;
            }

            llama_token token_to_decode = next;
            llama_batch token_batch = llama_batch_get_one(&token_to_decode, 1);
            const int decode_result = llama_decode(state->context, token_batch);
            if (decode_result == 2 || state->stop_requested.load(std::memory_order_relaxed)) {
                cancelled = true;
                break;
            }
            if (decode_result != 0) {
                LM_LOGE("Generation decode failed with code %d", decode_result);
                streamer.flush(generated);
                callback.on_error(
                    decode_result == 1 ? "CONTEXT_OVERFLOW" : "NATIVE_ERROR",
                    decode_result == 1
                        ? "The model ran out of context while generating."
                        : "llama.cpp could not continue decoding the response.");
                generation_error = true;
                break;
            }
            ++decoded_generated;
        }

        if (!matched_stop_sequence) {
            streamer.flush(generated);
        }

        const auto end = std::chrono::steady_clock::now();
        const auto generation_ms = std::max<int64_t>(1, std::chrono::duration_cast<std::chrono::milliseconds>(end - generation_start).count());
        callback.on_stats(
            generated,
            prompt_count,
            millis_since(overall_start),
            static_cast<double>(generated) * 1000.0 / static_cast<double>(generation_ms),
            prompt_count + decoded_generated,
            context_max);

        if (!generation_error) {
            callback.on_complete(generated, millis_since(overall_start), cancelled);
        }
    } catch (const std::bad_alloc & e) {
        LM_LOGE("Out of memory during generation: %s", e.what());
        callback.on_error("OUT_OF_MEMORY", "Android ran out of memory during local generation.");
    } catch (const std::exception & e) {
        LM_LOGE("Generation exception: %s", e.what());
        callback.on_error("NATIVE_ERROR", "The local inference engine encountered an internal error.");
    } catch (...) {
        LM_LOGE("Unknown generation exception");
        callback.on_error("NATIVE_ERROR", "The local inference engine encountered an internal error.");
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_localmuse_inference_nativebridge_NativeLlamaBridge_nativeStop(
    JNIEnv *, jobject, jlong handle) {
    EngineState * state = from_handle(handle);
    if (state != nullptr) {
        state->stop_requested.store(true, std::memory_order_relaxed);
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_localmuse_inference_nativebridge_NativeLlamaBridge_nativeUnload(
    JNIEnv *, jobject, jlong handle) {
    EngineState * state = from_handle(handle);
    if (state == nullptr) return;
    state->stop_requested.store(true, std::memory_order_relaxed);
    std::lock_guard<std::mutex> lock(state->mutex);
    state->unload_locked();
}

extern "C" JNIEXPORT void JNICALL
Java_com_localmuse_inference_nativebridge_NativeLlamaBridge_nativeDestroy(
    JNIEnv *, jobject, jlong handle) {
    EngineState * state = from_handle(handle);
    if (state == nullptr) return;
    state->stop_requested.store(true, std::memory_order_relaxed);
    {
        std::lock_guard<std::mutex> lock(state->mutex);
        state->unload_locked();
    }
    delete state;
}
