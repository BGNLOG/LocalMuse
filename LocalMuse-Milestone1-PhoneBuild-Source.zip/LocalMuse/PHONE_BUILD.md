# Build the signed APK from a phone

The included GitHub Actions workflow builds a real `arm64-v8a` LocalMuse APK with the pinned llama.cpp source and Android NDK. The debug APK is automatically signed by the Android build system and can be installed directly on a phone after allowing installs from the browser/GitHub app used to download it.

## From GitHub mobile/web

1. Create or open a GitHub repository and upload this project.
2. Open **Actions** → **Build signed Android APK**.
3. Tap **Run workflow**.
4. When the run completes, open it and download the artifact named **LocalMuse-Milestone1-signed-debug**.
5. Extract the artifact ZIP and install `LocalMuse-Milestone1-signed-debug.apk`.

The workflow installs Android API 36, NDK `29.0.13113456`, CMake `3.31.6`, Gradle `9.6.1`, then fetches the exact llama.cpp commit pinned by `scripts/bootstrap-llama.sh` before compiling.

This uses Android's debug signing key and is intended for direct testing, not Play Store publishing. A permanent private release keystore should be used before public distribution.
