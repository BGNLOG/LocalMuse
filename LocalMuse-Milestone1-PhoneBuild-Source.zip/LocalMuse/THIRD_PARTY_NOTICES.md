# Third-party notices

## llama.cpp

LocalMuse integrates `llama.cpp` from the upstream `ggml-org/llama.cpp` project at this pinned Git commit:

```text
3c9e747f7e8b456d81ee66ae679e943213fb7f7d
```

The source is fetched by the development bootstrap script into `third_party/llama.cpp`; it is not downloaded by the Android application at runtime.

`llama.cpp` is distributed under its upstream license. Preserve the upstream license/copyright files when producing source distributions or application releases that include its code/binaries.

Other Android/Kotlin dependencies are declared in the Gradle build files and retain their respective upstream licenses.
