# LocalMuse

LocalMuse is a privacy-first Android application for running compatible GGUF language models directly on-device with `llama.cpp`.

This repository currently contains **Milestone 1: Working Local Chat**.

## Milestone 1 features

- Android app written in Kotlin + Jetpack Compose + Material 3.
- ARM64 CPU inference through a small C++/JNI bridge into `llama.cpp`.
- No hosted inference API and no localhost HTTP inference server.
- No `INTERNET` permission in the Milestone 1 app manifest.
- Android Storage Access Framework model selection.
- Streaming GGUF import into app-private no-backup storage without loading the model into a Kotlin byte array.
- GGUF header validation, free-space headroom checks, partial-import cleanup, and atomic final rename.
- Memory-mapped model loading when supported by `llama.cpp`.
- One model loaded at a time, explicit unload, and conservative Galaxy A53 defaults.
- Embedded GGUF chat-template use when supported by `llama.cpp` (no hardcoded Qwen template).
- Token streaming into Compose as generation happens.
- Immediate stop flag wired into `llama.cpp`'s context abort callback, including prompt evaluation.
- Temperature, Top K, Top P, Min P, repeat penalty, max-output-token, seed and stop-sequence support in the inference API.
- Runtime token/context/speed statistics.
- UTF-8-safe native streaming so token byte boundaries do not corrupt emoji or non-ASCII text.
- A small Compose instrumentation smoke test and pure Kotlin model-configuration unit tests.

## Quick start

### Requirements

- Android Studio / Android SDK 36
- JDK 17 or newer (Gradle is configured to compile Java/Kotlin bytecode for Java 17)
- Android NDK `29.0.13113456`
- CMake `3.31.6`
- Git
- An ARM64 Android phone (`arm64-v8a`), initially optimized for the Samsung Galaxy A53 class of device

### 1. Fetch the pinned llama.cpp source

Linux/macOS:

```bash
./scripts/bootstrap-llama.sh
```

Windows PowerShell:

```powershell
./scripts/bootstrap-llama.ps1
```

The bootstrap script fetches exactly:

```text
3c9e747f7e8b456d81ee66ae679e943213fb7f7d
```

It does **not** fetch llama.cpp at app runtime.

### 2. Build

```bash
./gradlew :app:assembleDebug
```

The lightweight bootstrap launcher downloads and SHA-256-verifies Gradle 9.6.1 on first use. You may also import the project directly in Android Studio.

### 3. Install

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Because the debug build uses an application ID suffix, the installed ID is `com.localmuse.app.debug`.

### 4. Run

1. Launch LocalMuse.
2. Tap **Import GGUF**.
3. Choose a compatible decoder GGUF model from Android's document picker.
4. LocalMuse copies it into private no-backup storage, verifies the GGUF header, and loads it with llama.cpp.
5. Type a prompt and tap **Send**.
6. Tokens stream into the conversation as they are generated.
7. Tap **Stop** to abort generation, or **Unload** to release the model/context.

For a Galaxy A53 / ~6 GB RAM, start with a roughly 1–2B Q4-class model. The current default runtime profile is **2048 context / 4 threads / batch 256**.

## Architecture

```text
app / Compose
    |
    +-- feature-chat -------- UI + ViewModel state
    |       |
    |       +-- core-inference -- Kotlin inference contract/implementation
    |                              |
    |                              +-- JNI bridge
    |                                      |
    |                                      +-- C++ local engine
    |                                              |
    |                                              +-- llama.cpp
    |
    +-- feature-models ------ SAF import/private model storage
    +-- core-ui ------------- theme/privacy UI
    +-- core-model ---------- shared inference data contracts
```

The native engine is application-scoped rather than screen-scoped, so Activity recreation does not intentionally tear down a loaded model.

See [DEVELOPMENT.md](DEVELOPMENT.md) for build internals, pinned toolchain versions, current limitations, and the next milestone.
