package com.localmuse.chat

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.localmuse.inference.LocalInferenceEngine
import com.localmuse.inference.LocalInferenceException
import com.localmuse.models.ChatMessage
import com.localmuse.models.ChatRole
import com.localmuse.models.GenerationEvent
import com.localmuse.models.GenerationRequest
import com.localmuse.models.ModelConfig
import com.localmuse.models.ModelInfo
import com.localmuse.models.RuntimeStats
import com.localmuse.models.SamplingConfig
import com.localmuse.models.importer.ModelImportResult
import com.localmuse.models.importer.ModelImporter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatUiState(
    val modelStatus: ModelUiStatus = ModelUiStatus.Empty,
    val messages: List<ChatMessage> = emptyList(),
    val isGenerating: Boolean = false,
    val isStopping: Boolean = false,
    val sampling: SamplingConfig = SamplingConfig(),
    val modelConfig: ModelConfig = ModelConfig(),
    val stats: RuntimeStats = RuntimeStats(),
    val errorMessage: String? = null,
)

sealed interface ModelUiStatus {
    data object Empty : ModelUiStatus
    data class Importing(val displayName: String = "GGUF model") : ModelUiStatus
    data class Loading(val displayName: String) : ModelUiStatus
    data class Ready(val info: ModelInfo) : ModelUiStatus
    data class Failed(val message: String) : ModelUiStatus
}

class ChatViewModel(
    private val inference: LocalInferenceEngine,
    private val modelImporter: ModelImporter,
) : ViewModel() {
    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()

    fun importModel(uri: Uri) {
        if (_state.value.isGenerating) return
        viewModelScope.launch {
            _state.update {
                it.copy(
                    modelStatus = ModelUiStatus.Importing(),
                    errorMessage = null,
                    stats = RuntimeStats(),
                )
            }

            when (val imported = modelImporter.import(uri)) {
                is ModelImportResult.Failure -> {
                    _state.update {
                        it.copy(
                            modelStatus = ModelUiStatus.Failed(imported.message),
                            errorMessage = imported.message,
                        )
                    }
                }

                is ModelImportResult.Success -> {
                    _state.update {
                        it.copy(modelStatus = ModelUiStatus.Loading(imported.originalDisplayName))
                    }
                    val result = inference.loadModel(imported.file.absolutePath, _state.value.modelConfig)
                    result.fold(
                        onSuccess = { info ->
                            _state.update {
                                it.copy(
                                    modelStatus = ModelUiStatus.Ready(info),
                                    errorMessage = null,
                                )
                            }
                        },
                        onFailure = { throwable ->
                            val message = when (throwable) {
                                is LocalInferenceException -> throwable.userMessage
                                is OutOfMemoryError -> "Android does not have enough free RAM to load this model."
                                else -> "The GGUF model could not be loaded."
                            }
                            _state.update {
                                it.copy(
                                    modelStatus = ModelUiStatus.Failed(message),
                                    errorMessage = message,
                                )
                            }
                        },
                    )
                }
            }
        }
    }

    fun sendMessage(text: String) {
        val trimmed = text.trim()
        val snapshot = _state.value
        if (trimmed.isEmpty() || snapshot.isGenerating || snapshot.modelStatus !is ModelUiStatus.Ready) return

        val userMessage = ChatMessage(role = ChatRole.USER, content = trimmed)
        val assistantMessage = ChatMessage(role = ChatRole.ASSISTANT, content = "")
        val historyForRequest = snapshot.messages + userMessage

        _state.update {
            it.copy(
                messages = historyForRequest + assistantMessage,
                isGenerating = true,
                isStopping = false,
                errorMessage = null,
                stats = RuntimeStats(),
            )
        }

        viewModelScope.launch {
            try {
                inference.generate(
                    GenerationRequest(
                        messages = historyForRequest,
                        sampling = _state.value.sampling,
                    ),
                ).collect { event ->
                    when (event) {
                        is GenerationEvent.Started -> {
                            _state.update {
                                it.copy(
                                    stats = it.stats.copy(
                                        promptTokens = event.promptTokens,
                                        contextMaximum = event.contextSize,
                                        contextUsed = event.promptTokens,
                                    ),
                                )
                            }
                        }

                        is GenerationEvent.Token -> appendAssistantText(assistantMessage.id, event.text)
                        is GenerationEvent.Stats -> _state.update { it.copy(stats = event.stats) }
                        is GenerationEvent.Completed -> {
                            _state.update {
                                it.copy(
                                    isGenerating = false,
                                    isStopping = false,
                                    stats = event.stats,
                                )
                            }
                        }

                        is GenerationEvent.Cancelled -> {
                            _state.update {
                                it.copy(
                                    isGenerating = false,
                                    isStopping = false,
                                    stats = event.stats,
                                )
                            }
                        }

                        is GenerationEvent.Error -> {
                            _state.update {
                                it.copy(
                                    isGenerating = false,
                                    isStopping = false,
                                    errorMessage = event.failure.userMessage,
                                ).removeEmptyAssistant(assistantMessage.id)
                            }
                        }
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (t: Throwable) {
                _state.update {
                    it.copy(
                        isGenerating = false,
                        isStopping = false,
                        errorMessage = "Generation stopped unexpectedly.",
                    ).removeEmptyAssistant(assistantMessage.id)
                }
            } finally {
                _state.update { it.copy(isGenerating = false, isStopping = false) }
            }
        }
    }

    fun stopGeneration() {
        if (!_state.value.isGenerating || _state.value.isStopping) return
        _state.update { it.copy(isStopping = true) }
        viewModelScope.launch {
            inference.stopGeneration()
        }
    }

    fun unloadModel() {
        viewModelScope.launch {
            if (_state.value.isGenerating) {
                inference.stopGeneration()
            }
            inference.unloadModel()
            _state.update {
                it.copy(
                    modelStatus = ModelUiStatus.Empty,
                    isGenerating = false,
                    isStopping = false,
                    stats = RuntimeStats(),
                    errorMessage = null,
                )
            }
        }
    }

    fun updateSampling(transform: (SamplingConfig) -> SamplingConfig) {
        if (_state.value.isGenerating) return
        _state.update { it.copy(sampling = transform(it.sampling)) }
    }

    fun dismissError() {
        _state.update { it.copy(errorMessage = null) }
    }

    private fun appendAssistantText(messageId: String, chunk: String) {
        _state.update { current ->
            current.copy(
                messages = current.messages.map { message ->
                    if (message.id == messageId) message.copy(content = message.content + chunk) else message
                },
            )
        }
    }

    private fun ChatUiState.removeEmptyAssistant(messageId: String): ChatUiState {
        val message = messages.firstOrNull { it.id == messageId }
        return if (message?.content.isNullOrEmpty()) {
            copy(messages = messages.filterNot { it.id == messageId })
        } else {
            this
        }
    }

    class Factory(
        private val inference: LocalInferenceEngine,
        private val modelImporter: ModelImporter,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            require(modelClass.isAssignableFrom(ChatViewModel::class.java))
            return ChatViewModel(inference, modelImporter) as T
        }
    }
}
