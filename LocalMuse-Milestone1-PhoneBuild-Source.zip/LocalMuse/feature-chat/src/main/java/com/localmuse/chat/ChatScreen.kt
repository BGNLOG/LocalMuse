package com.localmuse.chat

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.localmuse.models.ChatMessage
import com.localmuse.models.ChatRole
import com.localmuse.models.ModelInfo
import com.localmuse.models.SamplingConfig
import com.localmuse.ui.components.PrivacyPill
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    onSelectModel: () -> Unit,
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var input by rememberSaveable { mutableStateOf("") }
    var settingsExpanded by rememberSaveable { mutableStateOf(false) }

    if (state.errorMessage != null) {
        AlertDialog(
            onDismissRequest = viewModel::dismissError,
            confirmButton = {
                TextButton(onClick = viewModel::dismissError) { Text("OK") }
            },
            title = { Text("Local inference issue") },
            text = { Text(state.errorMessage.orEmpty()) },
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("LocalMuse", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Private local AI",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
            )
        },
        bottomBar = {
            PromptBar(
                input = input,
                onInputChange = { input = it },
                canSend = state.modelStatus is ModelUiStatus.Ready && !state.isGenerating,
                isGenerating = state.isGenerating,
                isStopping = state.isStopping,
                onSend = {
                    val message = input
                    input = ""
                    viewModel.sendMessage(message)
                },
                onStop = viewModel::stopGeneration,
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp),
        ) {
            PrivacyPill()
            Spacer(Modifier.height(8.dp))

            ModelCard(
                status = state.modelStatus,
                isGenerating = state.isGenerating,
                onSelectModel = onSelectModel,
                onUnload = viewModel::unloadModel,
            )

            if (state.modelStatus is ModelUiStatus.Ready) {
                GenerationSettingsCard(
                    expanded = settingsExpanded,
                    onExpandedChange = { settingsExpanded = !settingsExpanded },
                    sampling = state.sampling,
                    enabled = !state.isGenerating,
                    onUpdate = viewModel::updateSampling,
                )
            }

            if (state.isGenerating || state.stats.tokensGenerated > 0) {
                RuntimeLine(state)
            }

            ChatMessageList(
                messages = state.messages,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun ModelCard(
    status: ModelUiStatus,
    isGenerating: Boolean,
    onSelectModel: () -> Unit,
    onUnload: () -> Unit,
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.elevatedCardColors(),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (status) {
                ModelUiStatus.Empty -> {
                    Text("No model loaded", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Choose a GGUF file. It is copied into LocalMuse's private storage so llama.cpp can memory-map it reliably.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(onClick = onSelectModel) { Text("Import GGUF") }
                }

                is ModelUiStatus.Importing -> {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator(modifier = Modifier.sizeIn(maxWidth = 28.dp, maxHeight = 28.dp))
                        Column {
                            Text("Importing model…", fontWeight = FontWeight.Medium)
                            Text("Copying without loading the file into RAM", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                is ModelUiStatus.Loading -> {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator(modifier = Modifier.sizeIn(maxWidth = 28.dp, maxHeight = 28.dp))
                        Column {
                            Text("Loading ${status.displayName}", fontWeight = FontWeight.Medium)
                            Text("CPU • ARM64 • 2048-token default context", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                is ModelUiStatus.Ready -> ModelReadyContent(status.info, isGenerating, onSelectModel, onUnload)

                is ModelUiStatus.Failed -> {
                    Text("Model not loaded", style = MaterialTheme.typography.titleMedium)
                    Text(status.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    Button(onClick = onSelectModel) { Text("Choose another GGUF") }
                }
            }
        }
    }
}

@Composable
private fun ModelReadyContent(
    info: ModelInfo,
    isGenerating: Boolean,
    onSelectModel: () -> Unit,
    onUnload: () -> Unit,
) {
    Text(info.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    Text(
        listOfNotNull(
            info.architecture.takeIf { it.isNotBlank() },
            info.quantization.takeIf { it.isNotBlank() },
            formatBytes(info.modelSizeBytes),
        ).joinToString(" • "),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Text(
        "Active context ${info.activeContextSize} • embedded template ${if (info.chatTemplate != null) "yes" else "no"}",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    if (info.modelSizeBytes > 2_200_000_000L) {
        Text(
            "Large model: this may be slow or fail to load on a 6 GB phone.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error,
        )
    }

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = onSelectModel, enabled = !isGenerating) { Text("Replace") }
        TextButton(onClick = onUnload, enabled = !isGenerating) { Text("Unload") }
    }
}

@Composable
private fun GenerationSettingsCard(
    expanded: Boolean,
    onExpandedChange: () -> Unit,
    sampling: SamplingConfig,
    enabled: Boolean,
    onUpdate: ((SamplingConfig) -> SamplingConfig) -> Unit,
) {
    Spacer(Modifier.height(8.dp))
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column {
                    Text("Generation settings", fontWeight = FontWeight.Medium)
                    Text(
                        "Temp ${format1(sampling.temperature)} • Top P ${format2(sampling.topP)} • ${sampling.maxOutputTokens} max tokens",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                TextButton(onClick = onExpandedChange) { Text(if (expanded) "Hide" else "Tune") }
            }

            if (expanded) {
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                SettingSlider(
                    label = "Temperature",
                    valueLabel = format2(sampling.temperature),
                    value = sampling.temperature,
                    valueRange = 0f..2f,
                    enabled = enabled,
                    onValueChange = { new -> onUpdate { it.copy(temperature = new) } },
                )
                SettingSlider(
                    label = "Top P",
                    valueLabel = format2(sampling.topP),
                    value = sampling.topP,
                    valueRange = 0.1f..1f,
                    enabled = enabled,
                    onValueChange = { new -> onUpdate { it.copy(topP = new) } },
                )
                SettingSlider(
                    label = "Min P",
                    valueLabel = format2(sampling.minP),
                    value = sampling.minP,
                    valueRange = 0f..0.3f,
                    enabled = enabled,
                    onValueChange = { new -> onUpdate { it.copy(minP = new) } },
                )
                SettingSlider(
                    label = "Top K",
                    valueLabel = sampling.topK.toString(),
                    value = sampling.topK.toFloat(),
                    valueRange = 0f..100f,
                    enabled = enabled,
                    onValueChange = { new -> onUpdate { it.copy(topK = new.roundToInt()) } },
                )
                SettingSlider(
                    label = "Repeat penalty",
                    valueLabel = format2(sampling.repetitionPenalty),
                    value = sampling.repetitionPenalty,
                    valueRange = 0.9f..1.3f,
                    enabled = enabled,
                    onValueChange = { new -> onUpdate { it.copy(repetitionPenalty = new) } },
                )
                SettingSlider(
                    label = "Max output tokens",
                    valueLabel = sampling.maxOutputTokens.toString(),
                    value = sampling.maxOutputTokens.toFloat(),
                    valueRange = 64f..1024f,
                    enabled = enabled,
                    onValueChange = { new ->
                        val stepped = (new / 32f).roundToInt() * 32
                        onUpdate { it.copy(maxOutputTokens = stepped.coerceIn(64, 1024)) }
                    },
                )
            }
        }
    }
}

@Composable
private fun SettingSlider(
    label: String,
    valueLabel: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    enabled: Boolean,
    onValueChange: (Float) -> Unit,
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall)
        Text(valueLabel, style = MaterialTheme.typography.labelMedium)
    }
    Slider(
        value = value,
        onValueChange = onValueChange,
        valueRange = valueRange,
        enabled = enabled,
    )
}

@Composable
private fun RuntimeLine(state: ChatUiState) {
    val stats = state.stats
    Text(
        buildString {
            append(stats.tokensGenerated)
            append(" tokens")
            if (stats.tokensPerSecond > 0.0) {
                append(" • ")
                append(String.format(Locale.US, "%.1f tok/s", stats.tokensPerSecond))
            }
            if (stats.contextMaximum > 0) {
                append(" • context ")
                append(stats.contextUsed)
                append('/')
                append(stats.contextMaximum)
            }
        },
        modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun ChatMessageList(
    messages: List<ChatMessage>,
    modifier: Modifier = Modifier,
) {
    val listState = rememberLazyListState()
    val shouldFollow by remember {
        derivedStateOf {
            val total = listState.layoutInfo.totalItemsCount
            if (total == 0) true
            else (listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0) >= total - 2
        }
    }
    val lastLength = messages.lastOrNull()?.content?.length ?: 0
    LaunchedEffect(messages.size, lastLength) {
        if (shouldFollow && messages.isNotEmpty()) {
            listState.scrollToItem(messages.lastIndex)
        }
    }

    if (messages.isEmpty()) {
        Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Your conversations stay on this device.", fontWeight = FontWeight.Medium)
                Text(
                    "Import a GGUF model, then start chatting. No network inference is used.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        state = listState,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { Spacer(Modifier.height(4.dp)) }
        items(messages, key = { it.id }) { message ->
            MessageBubble(message)
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == ChatRole.USER
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(if (isUser) 0.86f else 0.94f),
            shape = MaterialTheme.shapes.large,
            color = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        ) {
            SelectionContainer {
                Text(
                    text = if (message.content.isEmpty()) "…" else message.content,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
        }
    }
}

@Composable
private fun PromptBar(
    input: String,
    onInputChange: (String) -> Unit,
    canSend: Boolean,
    isGenerating: Boolean,
    isStopping: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit,
) {
    Surface(tonalElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(10.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = onInputChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text(if (canSend || isGenerating) "Message your local model" else "Load a GGUF model first") },
                enabled = !isGenerating,
                minLines = 1,
                maxLines = 6,
            )
            if (isGenerating) {
                Button(onClick = onStop, enabled = !isStopping) {
                    Text(if (isStopping) "Stopping…" else "Stop")
                }
            } else {
                Button(onClick = onSend, enabled = canSend && input.isNotBlank()) {
                    Text("Send")
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "Unknown size"
    val gib = bytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
    return if (gib >= 1.0) String.format(Locale.US, "%.2f GB", gib)
    else String.format(Locale.US, "%.0f MB", bytes.toDouble() / (1024.0 * 1024.0))
}

private fun format1(value: Float): String = String.format(Locale.US, "%.1f", value)
private fun format2(value: Float): String = String.format(Locale.US, "%.2f", value)
