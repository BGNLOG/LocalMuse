#!/usr/bin/env sh
set -eu

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
EXPECTED_LLAMA="3c9e747f7e8b456d81ee66ae679e943213fb7f7d"

echo "Checking privacy manifest..."
if grep -R "android.permission.INTERNET" "$ROOT/app/src/main" >/dev/null 2>&1; then
  echo "ERROR: Milestone 1 unexpectedly requests INTERNET." >&2
  exit 1
fi

echo "Checking llama.cpp pin..."
grep -q "$EXPECTED_LLAMA" "$ROOT/scripts/bootstrap-llama.sh"
grep -q "$EXPECTED_LLAMA" "$ROOT/scripts/bootstrap-llama.ps1"
grep -q "$EXPECTED_LLAMA" "$ROOT/DEVELOPMENT.md"

echo "Checking required native integration is present..."
grep -q "llama_model_load_from_file" "$ROOT/core-inference/src/main/cpp/localmuse_jni.cpp"
grep -q "llama_decode" "$ROOT/core-inference/src/main/cpp/localmuse_jni.cpp"
grep -q "llama_sampler_sample" "$ROOT/core-inference/src/main/cpp/localmuse_jni.cpp"
grep -q "llama_model_chat_template" "$ROOT/core-inference/src/main/cpp/localmuse_jni.cpp"

echo "Checking model defaults..."
grep -q 'contextSize: Int = 2_048' "$ROOT/core-model/src/main/java/com/localmuse/models/InferenceModels.kt"
grep -q 'batchSize: Int = 256' "$ROOT/core-model/src/main/java/com/localmuse/models/InferenceModels.kt"

echo "Static source checks passed."
