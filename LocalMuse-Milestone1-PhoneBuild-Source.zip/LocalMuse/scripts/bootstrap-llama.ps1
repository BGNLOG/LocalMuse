$ErrorActionPreference = "Stop"
$Commit = "3c9e747f7e8b456d81ee66ae679e943213fb7f7d"
$Root = Split-Path -Parent $PSScriptRoot
$Dest = Join-Path $Root "third_party\llama.cpp"
$Marker = Join-Path $Dest ".localmuse-commit"
$Header = Join-Path $Dest "include\llama.h"

if ((Test-Path $Marker) -and (Test-Path $Header) -and ((Get-Content $Marker -Raw).Trim() -eq $Commit)) {
    Write-Host "llama.cpp is already pinned at $Commit"
    exit 0
}

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw "git is required to fetch the pinned llama.cpp source."
}

if (Test-Path $Dest) { Remove-Item -Recurse -Force $Dest }
New-Item -ItemType Directory -Force $Dest | Out-Null
git -C $Dest init -q
git -C $Dest remote add origin https://github.com/ggml-org/llama.cpp.git
git -C $Dest fetch --depth 1 origin $Commit
git -C $Dest checkout -q --detach FETCH_HEAD
Set-Content -NoNewline -Path $Marker -Value $Commit
Write-Host "Fetched llama.cpp $Commit"
