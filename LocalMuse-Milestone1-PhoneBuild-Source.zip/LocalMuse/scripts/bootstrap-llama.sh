#!/usr/bin/env sh
set -eu

LLAMA_COMMIT="3c9e747f7e8b456d81ee66ae679e943213fb7f7d"
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
DEST="$ROOT/third_party/llama.cpp"

if [ -f "$DEST/.localmuse-commit" ] && [ "$(cat "$DEST/.localmuse-commit")" = "$LLAMA_COMMIT" ] && [ -f "$DEST/include/llama.h" ]; then
  echo "llama.cpp is already pinned at $LLAMA_COMMIT"
  exit 0
fi

command -v git >/dev/null 2>&1 || {
  echo "git is required to fetch the pinned llama.cpp source." >&2
  exit 1
}

rm -rf "$DEST"
mkdir -p "$DEST"
git -C "$DEST" init -q
git -C "$DEST" remote add origin https://github.com/ggml-org/llama.cpp.git
git -C "$DEST" fetch --depth 1 origin "$LLAMA_COMMIT"
git -C "$DEST" checkout -q --detach FETCH_HEAD
printf '%s\n' "$LLAMA_COMMIT" > "$DEST/.localmuse-commit"
echo "Fetched llama.cpp $LLAMA_COMMIT"
