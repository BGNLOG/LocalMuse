package com.localmuse.models.importer

import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.provider.OpenableColumns
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import kotlin.math.max

sealed interface ModelImportResult {
    data class Success(
        val file: File,
        val originalDisplayName: String,
        val bytes: Long,
    ) : ModelImportResult

    data class Failure(val message: String, val technicalDetail: String? = null) : ModelImportResult
}

class ModelImporter(private val context: Context) {
    private val modelDirectory: File
        get() = File(context.noBackupFilesDir, "models")

    suspend fun import(uri: Uri): ModelImportResult = withContext(Dispatchers.IO) {
        val metadata = try {
            readMetadata(uri)
        } catch (security: SecurityException) {
            return@withContext ModelImportResult.Failure(
                "Android no longer grants access to the selected model file. Select it again.",
                security.message,
            )
        }
        val displayName = metadata.first ?: "model.gguf"
        val declaredSize = metadata.second

        if (!displayName.endsWith(".gguf", ignoreCase = true)) {
            return@withContext ModelImportResult.Failure(
                "Please select a GGUF model file.",
            )
        }

        val directory = modelDirectory.apply { mkdirs() }
        if (!directory.isDirectory) {
            return@withContext ModelImportResult.Failure(
                "LocalMuse could not create its private model directory.",
            )
        }

        // A process kill during a large SAF copy can leave a hidden temporary file behind.
        // No active import can coexist with this importer instance in Milestone 1, so these
        // leftovers are safe to reclaim before checking free space for the next import.
        directory.listFiles { file -> file.isFile && file.name.endsWith(".partial") }
            ?.forEach { stale -> stale.delete() }

        if (declaredSize > 0) {
            val headroom = max(256L * 1024L * 1024L, declaredSize / 10L)
            val available = StatFs(directory.absolutePath).availableBytes
            if (available < declaredSize + headroom) {
                return@withContext ModelImportResult.Failure(
                    "There is not enough free storage to import this model safely.",
                    "Required model bytes=$declaredSize, available bytes=$available, reserved headroom=$headroom",
                )
            }
        }

        val safeName = sanitizeFileName(displayName)
        val destination = uniqueDestination(directory, safeName)
        val partial = File(directory, ".${destination.name}.${System.nanoTime()}.partial")

        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: return@withContext ModelImportResult.Failure("Android could not open the selected file.")

            var copied = 0L
            BufferedInputStream(input, COPY_BUFFER_SIZE).use { source ->
                FileOutputStream(partial).use { fileOutput ->
                    val target = BufferedOutputStream(fileOutput, COPY_BUFFER_SIZE)
                    val buffer = ByteArray(COPY_BUFFER_SIZE)
                    while (true) {
                        coroutineContext.ensureActive()
                        val read = source.read(buffer)
                        if (read < 0) break
                        target.write(buffer, 0, read)
                        copied += read
                    }
                    target.flush()
                    // Ensure bytes are durable before the atomic rename. This is important for
                    // 1+ GB imports where Android may kill the process soon after completion.
                    fileOutput.fd.sync()
                }
            }

            if (declaredSize > 0 && copied != declaredSize) {
                throw IOException("SAF size mismatch: expected $declaredSize bytes, copied $copied")
            }
            if (!hasGgufMagic(partial)) {
                partial.delete()
                return@withContext ModelImportResult.Failure(
                    "The selected file is not a valid GGUF file.",
                    "Missing GGUF magic header.",
                )
            }

            if (!partial.renameTo(destination)) {
                throw IOException("Could not atomically move imported model into place")
            }

            ModelImportResult.Success(
                file = destination,
                originalDisplayName = displayName,
                bytes = copied,
            )
        } catch (cancelled: CancellationException) {
            partial.delete()
            throw cancelled
        } catch (security: SecurityException) {
            partial.delete()
            ModelImportResult.Failure(
                "Android no longer grants access to the selected model file. Select it again.",
                security.message,
            )
        } catch (io: IOException) {
            partial.delete()
            ModelImportResult.Failure(
                if (StatFs(directory.absolutePath).availableBytes < 128L * 1024L * 1024L) {
                    "The model import stopped because the device is low on storage."
                } else {
                    "The model could not be copied into LocalMuse."
                },
                io.message,
            )
        } catch (t: Throwable) {
            partial.delete()
            ModelImportResult.Failure(
                "The model import failed unexpectedly.",
                t.message,
            )
        }
    }

    fun installedModelDirectory(): File = modelDirectory

    private fun readMetadata(uri: Uri): Pair<String?, Long> {
        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null,
            null,
            null,
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                val name = if (nameIndex >= 0 && !cursor.isNull(nameIndex)) cursor.getString(nameIndex) else null
                val size = if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) cursor.getLong(sizeIndex) else -1L
                return name to size
            }
        }
        return null to -1L
    }

    private fun hasGgufMagic(file: File): Boolean {
        if (file.length() < 4) return false
        val bytes = ByteArray(4)
        FileInputStream(file).use { input ->
            if (input.read(bytes) != bytes.size) return false
        }
        return bytes.contentEquals(byteArrayOf('G'.code.toByte(), 'G'.code.toByte(), 'U'.code.toByte(), 'F'.code.toByte()))
    }

    private fun sanitizeFileName(name: String): String {
        val cleaned = name
            .replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_")
            .trim()
            .take(180)
            .ifBlank { "model.gguf" }
        return if (cleaned.endsWith(".gguf", true)) cleaned else "$cleaned.gguf"
    }

    private fun uniqueDestination(directory: File, requestedName: String): File {
        var candidate = File(directory, requestedName)
        if (!candidate.exists()) return candidate
        val stem = requestedName.removeSuffix(".gguf").removeSuffix(".GGUF")
        var suffix = 2
        while (candidate.exists()) {
            candidate = File(directory, "$stem-$suffix.gguf")
            suffix++
        }
        return candidate
    }

    private companion object {
        const val COPY_BUFFER_SIZE = 1024 * 1024
    }
}
