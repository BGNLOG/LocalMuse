# LocalMuse Development Notes

## Status

Current implementation: **Milestone 1 — Working Local Chat**.

The source implements the complete local path:

```text
Compose chat UI
  -> ChatViewModel
  -> LocalInferenceEngine
  -> LlamaCppInferenceEngine
  -> NativeLlamaBridge (JNI)
  -> localmuse_jni.cpp
  -> llama.cpp
  -> local GGUF
```

No hosted inference service is used, and the Milestone 1 Android manifest intentionally requests no `INTERNET` permission.

## Toolchain pins

| Component | Version / revision |
|---|---|
| compileSdk / targetSdk | 36 / 36 |
| minSdk | 26 |
| Android Gradle Plugin | 9.4.1 |
| Gradle | 9.6.1 |
| Kotlin / Compose compiler plugin | 2.4.10 |
| Compose BOM | 2026.09.00 |
| Android NDK | 29.0.13113456 |
| CMake | 3.31.6 |
| C++ standard | C++17 |
| Supported ABI | arm64-v8a |
| llama.cpp commit | `3c9e747f7e8b456d81ee66ae679e943213fb7f7d` |

`llama.cpp` is not vendored in the generated archive. `scripts/bootstrap-llama.sh` / `.ps1` fetch exactly the commit above into `third_party/llama.cpp` before the native build.

## Module responsibilities

### `app`

- `LocalMuseApplication` owns a small application-scope dependency container.
- The `LlamaCppInferenceEngine` is application-scoped so normal Activity recreation does not reload a ~1 GB model.
- `MainActivity` launches Android's Storage Access Framework document picker and hosts Compose.
- No account, analytics, telemetry, advertising, or network permission is present.

### `core-model`

Pure data contracts for:

- chat messages and roles;
- conservative model runtime configuration;
- sampling configuration;
- generation requests/events;
- model metadata;
- runtime statistics;
- user-facing inference error codes.

Defaults are intentionally conservative for the first target phone:

- context: **2048**;
- threads: **4 maximum by default**;
- batch: **256**;
- GPU layers: **0**.

### `core-inference`

`LocalInferenceEngine` isolates the rest of the application from llama.cpp.

`LlamaCppInferenceEngine`:

- serializes model load/generate/unload on one dedicated worker thread;
- exposes streamed generation through Kotlin `Flow`;
- uses an atomic native stop call instead of queueing cancellation behind a busy generation worker;
- owns one native engine handle;
- translates native failure codes into stable Kotlin errors.

`localmuse_jni.cpp`:

- initializes the llama backend once per process;
- loads one model/context at a time;
- forces `n_gpu_layers = 0` for the CPU-first milestone;
- requests mmap loading when supported;
- sets context/batch/thread values from `ModelConfig`;
- disables K/Q/V and op offload for the CPU-first path;
- wires `abort_callback` to an atomic cancellation flag;
- rejects non-decoder models for this first milestone;
- reads architecture, quantization, parameter count, tensor size, trained context, active context and chat-template metadata;
- uses the model's embedded GGUF chat template through `llama_chat_apply_template` when one is present;
- deliberately does **not** hardcode a Qwen/ChatML template;
- falls back to a minimal generic User/Assistant transcript only when no template exists;
- performs prompt evaluation in bounded batches;
- builds a llama sampler chain for repeat penalty, Top K, Top P, Min P, temperature and seeded distribution sampling;
- streams generated token bytes to Kotlin;
- buffers partial UTF-8 and stop-sequence prefixes across token boundaries;
- explicitly frees sampler/context/model native resources.

### `feature-models`

`ModelImporter` uses SAF correctly for arbitrary Android document providers:

- queries display name/declared size where available;
- requires a `.gguf` selection;
- copies with a fixed 1 MiB buffer into `noBackupFilesDir/models`;
- reserves storage headroom before known-size imports;
- never reads the complete GGUF into JVM memory;
- fsyncs the completed temporary file;
- verifies the first four bytes are `GGUF`;
- atomically renames the completed import in the same directory;
- deletes failed/cancelled/stale `.partial` imports.

This copy is intentional for reliability: an arbitrary SAF provider URI is not guaranteed to expose a stable filesystem path that a native mmap can consume for the life of the model.

### `feature-chat`

Milestone 1 contains one in-memory conversation and provides:

- streamed assistant output;
- stop generation;
- model import/load/replace/unload;
- beginner sampler controls;
- responsive `LazyColumn` chat rendering;
- runtime token/speed/context display;
- local-inference privacy indicator.

### `core-ui`

Material 3 theme with system dark/light mode and Android 12+ dynamic color.

## Native build configuration

`core-inference/src/main/cpp/CMakeLists.txt` configures llama.cpp for ARM64 Android CPU inference:

- shared libraries enabled;
- llama examples/tests/server/tools disabled;
- CURL/OpenSSL integration disabled;
- `GGML_NATIVE=OFF` (do not compile for the build host CPU);
- `GGML_OPENMP=OFF`;
- llamafile disabled;
- CPU backend dynamic variants enabled;
- no Vulkan/GPU requirement.

Do not enable `-march=native` for the Android library. The APK must remain portable across ARM64 phones.

## Build instructions

### Android Studio

1. Install SDK Platform 36.
2. Install NDK `29.0.13113456` and CMake `3.31.6` through SDK Manager.
3. Run `scripts/bootstrap-llama.sh` (or the PowerShell equivalent).
4. Open the repository root in Android Studio.
5. Use JDK 17+ for Gradle.
6. Build/run the `app` configuration on an ARM64 device.

### Command line

```bash
./scripts/bootstrap-llama.sh
./gradlew :core-model:testDebugUnitTest
./gradlew :app:assembleDebug
```

With a connected ARM64 device/emulator:

```bash
./gradlew :app:connectedDebugAndroidTest
```

## Model path and memory behavior

Imported models are stored beneath:

```text
Context.noBackupFilesDir/models/
```

No absolute device path is hardcoded.

The model file is passed to llama.cpp by filesystem path after SAF import. llama.cpp can mmap the file instead of copying the entire model into an application-owned byte buffer. Only one model is retained at a time. Loading a replacement first unloads the old context/model.

The app intentionally ignores an advertised 32K/128K model context by default. The active M1 context is 2048 unless the Kotlin config is changed programmatically. Larger contexts increase KV/cache and runtime memory pressure.

## Cancellation

`generate()` executes on the dedicated native dispatcher. A regular coroutine cancellation queued to that same dispatcher would not interrupt a blocking native call quickly enough, so `stopGeneration()` invokes `nativeStop()` directly. That function only sets an atomic flag and is safe to call while generation owns the engine mutex.

The same flag is also passed to llama.cpp as its context abort callback. This lets cancellation interrupt both prompt evaluation and response decoding rather than only checking between generated tokens.

## Chat templates

The native prompt builder checks `llama_model_chat_template(model, nullptr)`.

- If present, it asks llama.cpp to apply that template with the conversation messages and generation prompt enabled.
- If llama.cpp cannot apply the embedded template, LocalMuse surfaces a template error rather than silently substituting a Qwen-specific prompt.
- If there is no template at all, the M1 generic fallback is used so base/instruct GGUF experimentation remains possible.

A future prompt-inspector/memory layer should live above this interface and pass structured messages rather than duplicating model-specific template logic.

## Error handling implemented in M1

User-facing paths exist for:

- invalid/non-GGUF import header;
- SAF permission loss;
- insufficient storage before a known-size import;
- failed/partial copy;
- model load failure;
- unsupported non-decoder model;
- native/JVM out-of-memory failures where catchable;
- unavailable tokenizer;
- unsupported embedded chat template;
- context overflow;
- native generation/decode failure;
- explicit cancellation.

Technical native diagnostics go to Android logcat under `LocalMuseNative`; raw C++ exceptions are not displayed to normal users.

## Tests and validation

Included automated source tests:

- `core-model` JUnit tests for conservative default configuration and validation;
- `app` Compose instrumentation smoke test that verifies the first-run local/no-model/import state.

Validation performed while producing this source bundle:

- the pure Kotlin inference-model source compiles with the available `kotlinc` compiler;
- `localmuse_jni.cpp` passes `clang++ -std=c++17 -Wall -Wextra -Werror -fsyntax-only` against JNI plus a header stub matching the llama.cpp APIs used by this bridge;
- the llama.cpp calls were checked against the current public llama.cpp header/API shape before pinning the revision;
- the manifest was checked to contain no `INTERNET` permission.

### Environment limitation of this generated bundle

The execution environment used to generate this repository does **not** contain an Android SDK/NDK and cannot resolve external Gradle/Git hosts from its shell. Therefore a real Gradle Android/NDK build, APK installation, GGUF load, token-generation benchmark, and Galaxy A53 hardware run could not be executed here. The source is structured to build on a normal Android development machine after fetching the pinned llama.cpp commit, but Milestone 1 should not be called physically hardware-verified until `assembleDebug`, instrumentation tests, and a GGUF smoke run pass on the target phone.

This limitation is intentionally documented rather than replacing inference with a fake implementation.

## Known Milestone 1 limitations

- Only `arm64-v8a` is enabled.
- CPU inference only; no Vulkan/GPU feature flag yet.
- One in-memory chat; Room persistence starts in Milestone 2.
- Imported model index is not persisted yet; the imported GGUF stays on disk but the M1 UI does not rediscover/select installed models after process death.
- No chat branching/regeneration/editing yet.
- No Markdown renderer yet.
- No automatic title generation yet.
- No prompt token-budget trimming, summary, memories, characters or personas yet.
- No model-download subsystem yet.
- No device benchmark/thermal governor yet.
- No background timeout/unload policy yet.
- No biometric/PIN lock/export yet.
- No explicit runtime RAM estimator yet.
- Model import progress is currently an indeterminate UI state (copy itself is streamed/cancellable).
- Split GGUF handling is not exposed by the importer UI in M1.
- The generic no-template fallback is intentionally simple and may be suboptimal for a model that omitted required prompt metadata.

## Next milestone — Milestone 2: Persistence

Planned next implementation:

1. Add Room behind a `core-database` module.
2. Add `Conversation`, `Message`, `GenerationVariant`, `InstalledModel` and `ModelProfile` entities/DAOs.
3. Persist imported model metadata and active selection without hardcoding paths.
4. Save streamed assistant generations transactionally after completion/cancellation.
5. Add multiple chats and conversation titles.
6. Add edit/regenerate while preserving previous variants.
7. Add the first message-tree/branch representation needed by later branching UI.
8. Add repository/DAO unit tests and migration tests.

Character/persona prompting, token budgeting and local summarization remain Milestones 3–4 so the working inference/storage foundations stay independently testable.
