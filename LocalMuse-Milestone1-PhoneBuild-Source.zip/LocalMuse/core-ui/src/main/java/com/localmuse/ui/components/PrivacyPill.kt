package com.localmuse.ui.components

import androidx.compose.material3.AssistChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

@Composable
fun PrivacyPill() {
    AssistChip(
        onClick = {},
        label = { Text("Generated entirely on this device") },
    )
}
