@echo off
setlocal enabledelayedexpansion
set "GRADLE_VERSION=9.6.1"
set "GRADLE_SHA256=9c0f7faeeb306cb14e4279a3e084ca6b596894089a0638e68a07c945a32c9e14"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "BOOTSTRAP_DIR=%GRADLE_USER_HOME%\localmuse-wrapper\gradle-%GRADLE_VERSION%"
set "GRADLE_BIN=%BOOTSTRAP_DIR%\gradle-%GRADLE_VERSION%\bin\gradle.bat"
set "ZIP=%BOOTSTRAP_DIR%\gradle-%GRADLE_VERSION%-bin.zip"
set "URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip"

if not exist "%GRADLE_BIN%" (
  if not exist "%BOOTSTRAP_DIR%" mkdir "%BOOTSTRAP_DIR%"
  if not exist "%ZIP%" (
    echo Downloading Gradle %GRADLE_VERSION%...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing '%URL%' -OutFile '%ZIP%'"
    if errorlevel 1 exit /b 1
  )
  for /f %%H in ('powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 '%ZIP%').Hash.ToLower()"') do set "ACTUAL=%%H"
  if /I not "!ACTUAL!"=="%GRADLE_SHA256%" (
    echo Gradle checksum mismatch; deleting untrusted download.
    del /q "%ZIP%"
    exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%BOOTSTRAP_DIR%'"
  if errorlevel 1 exit /b 1
)

call "%GRADLE_BIN%" %*
endlocal
